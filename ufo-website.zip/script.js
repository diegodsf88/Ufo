function beamMeUp() {
  alert("Kamu sedang diculik alien! 🛸👽");
}
