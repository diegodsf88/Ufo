# 🛸 UFO Zone

Project website sederhana bertema UFO.

## Fitur
- HTML, CSS, JavaScript
- Tema luar angkasa
- Tombol interaktif

## Cara menjalankan
Buka file `index.html` di browser.
